require('dotenv').config();
const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const { NewMessage } = require('telegram/events');
const input = require('input');
const fs = require('fs');
const path = require('path');

const { handleMessage } = require('./bot');

const API_ID = parseInt(process.env.API_ID, 10);
const API_HASH = process.env.API_HASH;
const OWNER_ID = parseInt(process.env.OWNER_ID, 10);

if (!API_ID || !API_HASH || !OWNER_ID) {
  console.error('❌ API_ID, API_HASH, OWNER_ID wajib diisi di .env');
  process.exit(1);
}

const SESSION_DIR = path.join(__dirname, 'session');
const SESSION_FILE = path.join(SESSION_DIR, 'userbot.session');

if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

function loadSession() {
  try {
    if (fs.existsSync(SESSION_FILE)) return fs.readFileSync(SESSION_FILE, 'utf8').trim();
  } catch (_) {}
  return '';
}

function saveSession(str) {
  try {
    fs.writeFileSync(SESSION_FILE, str);
  } catch (err) {
    console.error('[SESSION] Save error:', err.message);
  }
}

(async () => {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('   🤖 TELEGRAM USERBOT');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  const saved = loadSession();
  const session = new StringSession(saved);

  const client = new TelegramClient(session, API_ID, API_HASH, {
    connectionRetries: 5,
    useWSS: false
  });

  await client.start({
    phoneNumber: async () => await input.text('📱 Nomor Telegram (+62...): '),
    password: async () => await input.text('🔐 Password 2FA (kosongkan jika tidak ada): '),
    phoneCode: async () => await input.text('📨 Kode OTP: '),
    onError: (err) => console.error('[AUTH]', err.message)
  });

  const newSession = client.session.save();
  if (newSession && newSession !== saved) {
    saveSession(newSession);
    console.log('[SESSION] Tersimpan.');
  }

  const me = await client.getMe();
  console.log(`✅ Login: ${me.firstName || ''} ${me.lastName || ''} (@${me.username || '-'})`);
  console.log(`🆔 User ID: ${me.id}`);
  console.log(`👑 Owner ID: ${OWNER_ID}`);
  console.log(`📌 Prefix: ${process.env.PREFIX || '.'}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🚀 Userbot aktif. CTRL+C untuk keluar.');

  if (Number(me.id) !== OWNER_ID) {
    console.log('⚠️  Login bukan OWNER_ID yang dikonfigurasi.');
  }

  client.addEventHandler(async (event) => {
    try {
      await handleMessage(event, client);
    } catch (err) {
      console.error('[EVENT]', err.message);
    }
  }, new NewMessage({ incoming: false }));

  const shutdown = async (sig) => {
    console.log(`\n[SYSTEM] ${sig}, menutup...`);
    try { await client.disconnect(); } catch (_) {}
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('unhandledRejection', (r) => console.error('[UNHANDLED]', r));
  process.on('uncaughtException', (e) => console.error('[UNCAUGHT]', e.message));
})();