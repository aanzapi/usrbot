const fs = require('fs');
const path = require('path');
const config = require('./config');

const PREFIX = config.PREFIX || '.';
const DB_PATH = path.join(__dirname, 'database.json');

// ============ DATABASE ============
function loadDB() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify({ blacklist: [] }, null, 2));
      return { blacklist: [] };
    }
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    const parsed = JSON.parse(raw || '{}');
    return { blacklist: Array.isArray(parsed.blacklist) ? parsed.blacklist : [] };
  } catch (err) {
    console.error('[DB] Load error:', err.message);
    return { blacklist: [] };
  }
}

function saveDB(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('[DB] Save error:', err.message);
  }
}

let db = loadDB();

function isBlacklisted(id) {
  return db.blacklist.includes(Number(id));
}

function addBlacklist(id) {
  id = Number(id);
  if (db.blacklist.includes(id)) return false;
  db.blacklist.push(id);
  saveDB(db);
  return true;
}

function removeBlacklist(id) {
  id = Number(id);
  const before = db.blacklist.length;
  db.blacklist = db.blacklist.filter((x) => x !== id);
  saveDB(db);
  return db.blacklist.length < before;
}

// ============ HELPERS ============
function isOwner(id) {
  return Number(id) === Number(config.OWNER_ID);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function fmt(n) {
  return new Intl.NumberFormat('id-ID').format(n);
}

function mention(id, name) {
  const safe = (name || 'User').replace(/[<>]/g, '');
  return `[${safe}](tg://user?id=${id})`;
}

function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function detectMedia(msg) {
  if (!msg || !msg.media) return null;
  const { Api } = require('telegram');
  if (msg.media instanceof Api.MessageMediaPhoto) {
    return { type: 'photo', media: msg.media };
  }
  if (msg.media instanceof Api.MessageMediaDocument) {
    const doc = msg.media.document;
    if (doc && doc.mimeType) {
      if (doc.mimeType.startsWith('video/')) return { type: 'video', media: msg.media };
      if (doc.mimeType.startsWith('image/')) return { type: 'photo', media: msg.media };
    }
  }
  return null;
}

async function sendOne(client, targetId, text, mediaInfo) {
  if (mediaInfo) {
    await client.sendFile(targetId, {
      file: mediaInfo.media,
      caption: text || '',
      supportsStreaming: mediaInfo.type === 'video'
    });
  } else {
    await client.sendMessage(targetId, { message: text });
  }
}

// ============ MENU ============
async function cmdMenu(event, client, args, senderId) {
  const owner = isOwner(senderId);
  const lines = [
    '╔══════════════════════╗',
    '   🤖 TELEGRAM USERBOT',
    '╚══════════════════════╝',
    '',
    '📋 **DAFTAR COMMAND**',
    '',
    '🔹 `.menu` — Tampilkan menu ini',
    '🔹 `.tagall` — Mention semua member group',
    '🔹 `.tagall <teks>` — Mention dengan teks kustom',
    ''
  ];

  if (owner) {
    lines.push(
      '👑 **OWNER COMMANDS**',
      '',
      '🔸 `.broadcast <teks>` — BC ke group + private',
      '🔸 `.bcgroup <teks>` — BC hanya ke group',
      '🔸 `.bcprivate <teks>` — BC hanya ke private',
      '🔸 `.addbl <id|reply>` — Tambah ke blacklist',
      '🔸 `.delbl <id|reply>` — Hapus dari blacklist',
      '🔸 `.listbl` — Lihat blacklist',
      '',
      '💡 Reply foto/video + command broadcast = kirim media',
      `⏱️ Delay: ${config.BROADCAST_DELAY}ms`
    );
  } else {
    lines.push('_(Command owner tidak tersedia)_');
  }

  lines.push('', '──────────────────────', `📌 Prefix: \`${PREFIX}\``);
  await event.reply({ message: lines.join('\n'), parseMode: 'markdown' });
}

// ============ TAGALL ============
async function cmdTagall(event, client, args) {
  if (!event.isGroup && !event.isChannel) {
    return event.reply('❌ Command ini hanya bisa dipakai di group.');
  }

  const silent = args.includes('--silent');
  const customText = args.filter((a) => a !== '--silent').join(' ').trim();
  const header = customText ? `📢 ${customText}` : '📢 **ATTENTION EVERYONE**';

  let participants;
  try {
    participants = await client.getParticipants(event.chatId, {
      limit: 10000,
      aggressive: true
    });
  } catch (err) {
    return event.reply(`❌ Gagal ambil member: ${err.message}`);
  }

  const mentionable = participants.filter((p) => p && p.id && !p.bot && !p.deleted && !p.self);

  if (mentionable.length === 0) return event.reply('❌ Tidak ada member yang bisa di-mention.');

  const total = mentionable.length;
  const progress = await event.reply(`⏳ Mention **${fmt(total)}** member...`).catch(() => null);

  const batches = chunk(mentionable, 5);
  let sent = 0;
  let failed = 0;

  if (!silent) {
    try {
      await event.reply({ message: header, parseMode: 'markdown' });
    } catch (_) {}
  }

  for (const batch of batches) {
    const names = batch.map((p) => {
      const name = [p.firstName, p.lastName].filter(Boolean).join(' ') || p.username || 'User';
      return mention(p.id, name);
    });

    try {
      await event.reply({ message: names.join(' '), parseMode: 'markdown', replyTo: event.id });
      sent += batch.length;
    } catch (err) {
      if (err && err.seconds) {
        await sleep((err.seconds + 2) * 1000);
        try {
          await event.reply({ message: names.join(' '), parseMode: 'markdown', replyTo: event.id });
          sent += batch.length;
        } catch (_) {
          failed += batch.length;
        }
      } else {
        failed += batch.length;
      }
    }

    await sleep(1200);
  }

  const summary = `✅ **TagAll Selesai**\n\n👥 Total: ${fmt(total)}\n✅ Terkirim: ${fmt(sent)}\n❌ Gagal: ${fmt(failed)}`;
  if (progress && typeof progress.edit === 'function') {
    await progress.edit({ message: summary, parseMode: 'markdown' }).catch(() => {});
  } else {
    await event.reply({ message: summary, parseMode: 'markdown' }).catch(() => {});
  }
}

// ============ BROADCAST CORE ============
async function collectTargets(client, mode) {
  const groups = [];
  const privates = [];
  const dialogs = await client.getDialogs({ limit: 1000 });

  for (const d of dialogs) {
    try {
      const e = d.entity;
      if (!e) continue;
      if (d.isUser) {
        if (e.bot || e.self || e.deleted) continue;
        privates.push(d.id);
      } else if (d.isGroup) {
        if (e.left) continue;
        groups.push(d.id);
      }
    } catch (_) {}
  }

  let targets = [];
  if (mode === 'group') targets = groups;
  else if (mode === 'private') targets = privates;
  else targets = [...groups, ...privates];

  targets = targets.filter((id) => !isBlacklisted(id));
  return { targets, groups, privates };
}

async function runBroadcast(client, event, text, mediaInfo, mode) {
  const { targets, groups, privates } = await collectTargets(client, mode);

  if (targets.length === 0) {
    return event.reply('❌ Tidak ada target valid untuk broadcast.');
  }

  const label =
    mode === 'group' ? 'GROUP' :
    mode === 'private' ? 'PRIVATE' :
    'GROUP + PRIVATE';

  await event.reply(
    `📢 **Broadcast dimulai**\n\n🎯 Mode: **${label}**\n👥 Total: **${fmt(targets.length)}**\n` +
    `   • Group: ${fmt(groups.length)}\n   • Private: ${fmt(privates.length)}\n` +
    `⏱️ Delay: ${config.BROADCAST_DELAY}ms\n\n_Sedang mengirim..._`,
    { parseMode: 'markdown' }
  );

  const start = Date.now();
  let success = 0;
  let failed = 0;
  const failedIds = [];

  for (let i = 0; i < targets.length; i++) {
    const id = targets[i];
    if (isBlacklisted(id)) continue;

    try {
      await sendOne(client, id, text, mediaInfo);
      success++;
    } catch (err) {
      if (err && err.seconds) {
        console.log(`[BC] FloodWait ${err.seconds}s → ${id}`);
        await sleep((err.seconds + 2) * 1000);
        try {
          await sendOne(client, id, text, mediaInfo);
          success++;
        } catch (_) {
          failed++;
          failedIds.push(id);
        }
      } else {
        failed++;
        failedIds.push(id);
      }
    }

    if (i < targets.length - 1) await sleep(config.BROADCAST_DELAY);
  }

  const dur = Math.floor((Date.now() - start) / 1000);
  const report = [
    '✅ **Broadcast Selesai**',
    '',
    `🎯 Mode: **${label}**`,
    `👥 Total: ${fmt(targets.length)}`,
    `✅ Berhasil: ${fmt(success)}`,
    `❌ Gagal: ${fmt(failed)}`,
    `⏱️ Durasi: ${dur}s`
  ];

  if (failedIds.length > 0 && failedIds.length <= 30) {
    report.push('', '❌ **Target gagal:**');
    for (const id of failedIds) report.push(`• \`${id}\``);
  }

  await event.reply({ message: report.join('\n'), parseMode: 'markdown' });
}

// ============ BROADCAST COMMANDS ============
async function cmdBroadcast(event, client, args) {
  const text = args.join(' ').trim();
  const reply = await event.getReplyMessage().catch(() => null);
  if (!text && !reply) return event.reply('❌ Gunakan: `.broadcast <teks>` atau reply media.');

  let mediaInfo = null;
  if (reply) mediaInfo = detectMedia(reply);

  await runBroadcast(client, event, text, mediaInfo, 'all');
}

async function cmdBcGroup(event, client, args) {
  const text = args.join(' ').trim();
  const reply = await event.getReplyMessage().catch(() => null);
  if (!text && !reply) return event.reply('❌ Gunakan: `.bcgroup <teks>` atau reply media.');

  let mediaInfo = null;
  if (reply) mediaInfo = detectMedia(reply);

  await runBroadcast(client, event, text, mediaInfo, 'group');
}

async function cmdBcPrivate(event, client, args) {
  const text = args.join(' ').trim();
  const reply = await event.getReplyMessage().catch(() => null);
  if (!text && !reply) return event.reply('❌ Gunakan: `.bcprivate <teks>` atau reply media.');

  let mediaInfo = null;
  if (reply) mediaInfo = detectMedia(reply);

  await runBroadcast(client, event, text, mediaInfo, 'private');
}

// ============ BLACKLIST ============
async function resolveTargetId(event, args) {
  if (args.length > 0) {
    const n = parseInt(args[0], 10);
    if (!isNaN(n)) return n;
  }
  const reply = await event.getReplyMessage().catch(() => null);
  if (reply && reply.senderId) return Number(reply.senderId);
  return null;
}

async function cmdAddBl(event, client, args) {
  const id = await resolveTargetId(event, args);
  if (!id) return event.reply('❌ Gunakan: `.addbl <id>` atau reply pesan user.');
  const added = addBlacklist(id);
  await event.reply(
    added ? `✅ \`${id}\` ditambahkan ke blacklist.` : `ℹ️ \`${id}\` sudah ada.`,
    { parseMode: 'markdown' }
  );
}

async function cmdDelBl(event, client, args) {
  const id = await resolveTargetId(event, args);
  if (!id) return event.reply('❌ Gunakan: `.delbl <id>` atau reply pesan user.');
  const removed = removeBlacklist(id);
  await event.reply(
    removed ? `✅ \`${id}\` dihapus dari blacklist.` : `ℹ️ \`${id}\` tidak ada di blacklist.`,
    { parseMode: 'markdown' }
  );
}

async function cmdListBl(event) {
  const list = db.blacklist;
  if (list.length === 0) return event.reply('📭 Blacklist kosong.');
  const lines = [`🚫 **BLACKLIST** (${fmt(list.length)})`, ''];
  list.forEach((id, i) => lines.push(`${i + 1}. \`${id}\``));
  await event.reply({ message: lines.join('\n'), parseMode: 'markdown' });
}

// ============ COMMAND REGISTRY ============
const COMMANDS = {
  menu: { run: cmdMenu, ownerOnly: false },
  tagall: { run: cmdTagall, ownerOnly: false },
  broadcast: { run: cmdBroadcast, ownerOnly: true, aliases: ['bc'] },
  bcgroup: { run: cmdBcGroup, ownerOnly: true, aliases: ['bcg'] },
  bcprivate: { run: cmdBcPrivate, ownerOnly: true, aliases: ['bcp'] },
  addbl: { run: cmdAddBl, ownerOnly: true },
  delbl: { run: cmdDelBl, ownerOnly: true },
  listbl: { run: cmdListBl, ownerOnly: true }
};

function resolveCommand(name) {
  name = name.toLowerCase();
  if (COMMANDS[name]) return COMMANDS[name];
  for (const key of Object.keys(COMMANDS)) {
    const c = COMMANDS[key];
    if (c.aliases && c.aliases.includes(name)) return c;
  }
  return null;
}

// ============ HANDLER UTAMA ============
async function handleMessage(event, client) {
  try {
    const msg = event.message;
    if (!msg || !msg.message) return;
    const text = msg.message.trim();
    if (!text.startsWith(PREFIX)) return;

    const without = text.slice(PREFIX.length).trim();
    if (!without) return;

    const parts = without.split(/\s+/);
    const name = parts[0];
    const args = parts.slice(1);

    const cmd = resolveCommand(name);
    if (!cmd) return;

    const senderId = event.senderId ? Number(event.senderId) : null;

    if (cmd.ownerOnly && !isOwner(senderId)) {
      return event.reply('⛔ Command ini hanya untuk Owner.').catch(() => {});
    }

    await cmd.run(event, client, args, senderId);
  } catch (err) {
    console.error('[HANDLER]', err.message);
    try { await event.reply(`❌ Error: ${err.message}`); } catch (_) {}
  }
}

module.exports = { handleMessage };