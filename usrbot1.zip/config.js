require("dotenv").config();

module.exports = {
  API_ID: parseInt(process.env.API_ID, 10),
  API_HASH: process.env.API_HASH,
  OWNER_ID: parseInt(process.env.OWNER_ID, 10),
  PREFIX: process.env.PREFIX || ".",
  BROADCAST_DELAY: parseInt(process.env.BROADCAST_DELAY, 10) || 2000
};