const fs = require("fs");
const path = require("path");

const { Api } = require("telegram");

const config = require("./config");

const DB_FILE = path.join(__dirname, "database.json");

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function fmt(n) {
  return new Intl.NumberFormat("id-ID").format(Number(n) || 0);
}

function isOwner(id) {
  if (id === undefined || id === null) {
    return false;
  }

  return Number(id) === Number(config.OWNER_ID);
}

function mention(id, name) {
  const safeName = String(name || "User")
    .replace(/]/g, "")
    .replace(/\[/g, "");

  return `[${safeName}](tg://user?id=${id})`;
}

function chunk(arr, size) {
  const result = [];

  for (let i = 0; i < arr.length; i += size) {
    result.push(arr.slice(i, i + size));
  }

  return result;
}

function loadDB() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const defaultDB = {
        blacklist: []
      };

      fs.writeFileSync(
        DB_FILE,
        JSON.stringify(defaultDB, null, 2),
        "utf8"
      );

      return defaultDB;
    }

    const raw = fs.readFileSync(DB_FILE, "utf8").trim();

    if (!raw) {
      return {
        blacklist: []
      };
    }

    const parsed = JSON.parse(raw);

    if (!Array.isArray(parsed.blacklist)) {
      parsed.blacklist = [];
    }

    return parsed;
  } catch (err) {
    console.error("[DATABASE LOAD ERROR]", err);

    return {
      blacklist: []
    };
  }
}

function saveDB(db) {
  try {
    fs.writeFileSync(
      DB_FILE,
      JSON.stringify(db, null, 2),
      "utf8"
    );

    return true;
  } catch (err) {
    console.error("[DATABASE SAVE ERROR]", err);
    return false;
  }
}

function normalizeId(id) {
  if (id === undefined || id === null) {
    return null;
  }

  const value = String(id).trim();

  if (!/^-?\d+$/.test(value)) {
    return null;
  }

  return value;
}

function isBlacklisted(id) {
  const normalized = normalizeId(id);

  if (!normalized) {
    return false;
  }

  const db = loadDB();

  return db.blacklist.some(
    (item) => String(item) === normalized
  );
}

function addBlacklist(id) {
  const normalized = normalizeId(id);

  if (!normalized) {
    return false;
  }

  const db = loadDB();

  if (
    db.blacklist.some(
      (item) => String(item) === normalized
    )
  ) {
    return false;
  }

  db.blacklist.push(normalized);

  saveDB(db);

  return true;
}

function removeBlacklist(id) {
  const normalized = normalizeId(id);

  if (!normalized) {
    return false;
  }

  const db = loadDB();

  const oldLength = db.blacklist.length;

  db.blacklist = db.blacklist.filter(
    (item) => String(item) !== normalized
  );

  if (db.blacklist.length === oldLength) {
    return false;
  }

  saveDB(db);

  return true;
}

async function reply(event, text, opts = {}) {
  if (!event || !event.message) {
    return null;
  }

  return await event.message.reply({
    message: text,
    ...opts
  });
}

async function getReplyMessage(event) {
  if (!event || !event.message) {
    return null;
  }

  return await event.message.getReplyMessage();
}

function detectMedia(msg) {
  if (!msg || !msg.media) {
    return null;
  }

  if (msg.media instanceof Api.MessageMediaPhoto) {
    return {
      type: "photo",
      media: msg.media
    };
  }

  if (msg.media instanceof Api.MessageMediaDocument) {
    const document = msg.media.document;

    if (!document) {
      return null;
    }

    const mimeType = String(document.mimeType || "")
      .toLowerCase();

    if (mimeType.startsWith("video/")) {
      return {
        type: "video",
        media: msg.media
      };
    }

    if (mimeType.startsWith("image/")) {
      return {
        type: "photo",
        media: msg.media
      };
    }
  }

  return null;
}

function getSenderId(event) {
  if (!event || !event.message) {
    return null;
  }

  if (event.message.senderId !== undefined) {
    return Number(event.message.senderId);
  }

  return null;
}

function getEntityId(entity) {
  if (!entity || entity.id === undefined) {
    return null;
  }

  return String(entity.id);
}

function isDeletedUser(entity) {
  return Boolean(
    entity &&
    (
      entity instanceof Api.User &&
      entity.deleted === true
    )
  );
}

function isBotUser(entity) {
  return Boolean(
    entity &&
    (
      entity instanceof Api.User &&
      entity.bot === true
    )
  );
}

function isPrivateUser(entity) {
  return Boolean(
    entity &&
    entity instanceof Api.User &&
    !entity.bot &&
    !entity.deleted
  );
}

function isGroupEntity(entity) {
  if (!entity) {
    return false;
  }

  if (entity instanceof Api.Chat) {
    return true;
  }

  if (entity instanceof Api.Channel) {
    return Boolean(entity.megagroup === true);
  }

  return false;
}

function isBroadcastChannel(entity) {
  return Boolean(
    entity instanceof Api.Channel &&
    entity.broadcast === true &&
    entity.megagroup !== true
  );
}

function getDisplayName(entity) {
  if (!entity) {
    return "User";
  }

  if (entity instanceof Api.User) {
    const first = entity.firstName || "";
    const last = entity.lastName || "";
    const full = `${first} ${last}`.trim();

    if (full) {
      return full;
    }

    if (entity.username) {
      return `@${entity.username}`;
    }

    return String(entity.id);
  }

  if (entity.title) {
    return entity.title;
  }

  return String(entity.id);
}

function getFloodWaitSeconds(err) {
  if (!err) {
    return 0;
  }

  if (
    err.seconds !== undefined &&
    Number.isFinite(Number(err.seconds))
  ) {
    return Number(err.seconds);
  }

  if (
    err.errorMessage &&
    typeof err.errorMessage === "string"
  ) {
    const match = err.errorMessage.match(
      /FLOOD_WAIT[_ ]?(\d+)/i
    );

    if (match) {
      return Number(match[1]);
    }
  }

  if (err.message && typeof err.message === "string") {
    const match = err.message.match(
      /FLOOD_WAIT[_ ]?(\d+)/i
    );

    if (match) {
      return Number(match[1]);
    }
  }

  return 0;
}

function parseCommand(text) {
  if (!text || typeof text !== "string") {
    return null;
  }

  const prefix = config.PREFIX;

  if (!text.startsWith(prefix)) {
    return null;
  }

  const withoutPrefix = text.slice(prefix.length).trim();

  if (!withoutPrefix) {
    return null;
  }

  const firstSpace = withoutPrefix.search(/\s/);

  let command;
  let args;

  if (firstSpace === -1) {
    command = withoutPrefix.toLowerCase();
    args = "";
  } else {
    command = withoutPrefix
      .slice(0, firstSpace)
      .toLowerCase();

    args = withoutPrefix
      .slice(firstSpace + 1)
      .trim();
  }

  return {
    command,
    args
  };
}

async function sendBroadcastMedia(
  client,
  target,
  mediaInfo,
  caption
) {
  return await client.sendFile(target, {
    file: mediaInfo.media,
    caption: caption || ""
  });
}

async function sendBroadcastText(
  client,
  target,
  text
) {
  return await client.sendMessage(target, {
    message: text
  });
}

async function sendWithFloodRetry(
  sendFunction
) {
  try {
    await sendFunction();
    return {
      success: true,
      retried: false
    };
  } catch (err) {
    const seconds = getFloodWaitSeconds(err);

    if (!seconds) {
      return {
        success: false,
        retried: false,
        error: err
      };
    }

    console.log(
      `[BROADCAST] FloodWait ${seconds}s. Retry sekali setelah menunggu.`
    );

    await sleep((seconds + 2) * 1000);

    try {
      await sendFunction();

      return {
        success: true,
        retried: true
      };
    } catch (retryError) {
      return {
        success: false,
        retried: true,
        error: retryError
      };
    }
  }
}

async function getBroadcastTargets(
  client,
  mode,
  blacklist
) {
  const dialogs = await client.getDialogs({
    limit: 1000
  });

  const targets = [];
  const seen = new Set();

  for (const dialog of dialogs) {
    try {
      const entity = dialog.entity;

      if (!entity) {
        continue;
      }

      const entityId = getEntityId(entity);

      if (!entityId) {
        continue;
      }

      if (seen.has(entityId)) {
        continue;
      }

      seen.add(entityId);

      if (
        blacklist.some(
          (id) => String(id) === String(entityId)
        )
      ) {
        continue;
      }

      if (entity instanceof Api.User) {
        if (isDeletedUser(entity)) {
          continue;
        }

        if (isBotUser(entity)) {
          continue;
        }

        if (
          Number(entity.id) === Number(config.OWNER_ID)
        ) {
          continue;
        }

        if (
          mode === "broadcast" ||
          mode === "private"
        ) {
          if (isPrivateUser(entity)) {
            targets.push(entity);
          }
        }

        continue;
      }

      if (isGroupEntity(entity)) {
        if (
          mode === "broadcast" ||
          mode === "group"
        ) {
          targets.push(entity);
        }

        continue;
      }

      if (isBroadcastChannel(entity)) {
        continue;
      }
    } catch (err) {
      console.error(
        "[TARGET FILTER ERROR]",
        err
      );
    }
  }

  return targets;
}

async function executeBroadcast(
  event,
  client,
  mode,
  payload
) {
  const db = loadDB();

  const mediaInfo = payload.mediaInfo;
  const text = payload.text || "";

  let targets;

  try {
    targets = await getBroadcastTargets(
      client,
      mode,
      db.blacklist
    );
  } catch (err) {
    await reply(
      event,
      `Gagal mengambil daftar target.\n\nError: ${err.message}`
    );

    return;
  }

  const total = targets.length;
  let success = 0;
  let failed = 0;

  const startedAt = Date.now();

  await reply(
    event,
    [
      "Broadcast dimulai.",
      "",
      `Mode: ${mode}`,
      `Target: ${fmt(total)}`,
      `Delay: ${fmt(config.BROADCAST_DELAY)} ms`
    ].join("\n")
  );

  for (let index = 0; index < targets.length; index++) {
    const target = targets[index];

    try {
      const result = await sendWithFloodRetry(
        async () => {
          if (mediaInfo) {
            await sendBroadcastMedia(
              client,
              target,
              mediaInfo,
              text
            );
          } else {
            await sendBroadcastText(
              client,
              target,
              text
            );
          }
        }
      );

      if (result.success) {
        success++;

        console.log(
          `[BROADCAST] ${index + 1}/${total} SUCCESS -> ${getDisplayName(target)}`
        );
      } else {
        failed++;

        console.error(
          `[BROADCAST] ${index + 1}/${total} FAILED -> ${getDisplayName(target)}`,
          result.error
        );
      }
    } catch (err) {
      failed++;

      console.error(
        `[BROADCAST] ${index + 1}/${total} ERROR -> ${getDisplayName(target)}`,
        err
      );
    }

    if (index < targets.length - 1) {
      await sleep(config.BROADCAST_DELAY);
    }
  }

  const durationMs = Date.now() - startedAt;
  const durationSec = (durationMs / 1000).toFixed(1);

  await reply(
    event,
    [
      "Broadcast selesai.",
      "",
      `Total target : ${fmt(total)}`,
      `Berhasil     : ${fmt(success)}`,
      `Gagal        : ${fmt(failed)}`,
      `Durasi       : ${durationSec} detik`
    ].join("\n")
  );
}

async function handleMenu(
  event,
  owner
) {
  const lines = [
    "╭━━━「 USERBOT 」━━━╮",
    `┃ Prefix: ${config.PREFIX}`,
    "┃",
    `┃ ${config.PREFIX}menu`,
    `┃ ${config.PREFIX}tagall [teks]`,
    "┃"
  ];

  if (owner) {
    lines.push(
      `┃ ${config.PREFIX}broadcast <teks>`,
      `┃ ${config.PREFIX}bc <teks>`,
      `┃ ${config.PREFIX}bcgroup <teks>`,
      `┃ ${config.PREFIX}bcg <teks>`,
      `┃ ${config.PREFIX}bcprivate <teks>`,
      `┃ ${config.PREFIX}bcp <teks>`,
      `┃`,
      `┃ ${config.PREFIX}addbl <id/reply>`,
      `┃ ${config.PREFIX}delbl <id/reply>`,
      `┃ ${config.PREFIX}listbl`
    );
  }

  lines.push(
    "╰━━━━━━━━━━━━━━━━━━╯"
  );

  await reply(
    event,
    lines.join("\n")
  );
}

async function handleTagAll(
  event,
  client,
  args
) {
  const chat = await event.message.getChat();

  if (!chat) {
    await reply(
      event,
      "Chat tidak ditemukan."
    );

    return;
  }

  if (!isGroupEntity(chat)) {
    await reply(
      event,
      "Command .tagall hanya dapat digunakan di group."
    );

    return;
  }

  const customText = args || "Member group";

  let participants;

  try {
    participants = await client.getParticipants(
      chat
    );
  } catch (err) {
    const seconds = getFloodWaitSeconds(err);

    if (seconds) {
      await reply(
        event,
        `Telegram meminta FloodWait ${fmt(seconds)} detik.`
      );
      await sleep((seconds + 2) * 1000);

      try {
        participants = await client.getParticipants(
          chat
        );
      } catch (retryError) {
        await reply(
          event,
          `Gagal mengambil member group.\n\nError: ${retryError.message}`
        );

        return;
      }
    } else {
      await reply(
        event,
        `Gagal mengambil member group.\n\nError: ${err.message}`
      );

      return;
    }
  }

  const self = await client.getMe();

  const filtered = [];

  for (const participant of participants) {
    if (!participant) {
      continue;
    }

    if (!(participant instanceof Api.User)) {
      continue;
    }

    if (participant.deleted === true) {
      continue;
    }

    if (participant.bot === true) {
      continue;
    }

    if (
      Number(participant.id) === Number(self.id)
    ) {
      continue;
    }

    filtered.push(participant);
  }

  const batches = chunk(filtered, 5);

  let success = 0;
  let failed = 0;

  for (
    let batchIndex = 0;
    batchIndex < batches.length;
    batchIndex++
  ) {
    const batch = batches[batchIndex];

    const mentions = batch.map((user) => {
      return mention(
        user.id,
        getDisplayName(user)
      );
    });

    const message = [
      customText,
      "",
      mentions.join(" ")
    ].join("\n");

    try {
      await client.sendMessage(
        chat,
        {
          message
        }
      );

      success += batch.length;
    } catch (err) {
      const seconds = getFloodWaitSeconds(err);

      if (seconds) {
        await sleep((seconds + 2) * 1000);

        try {
          await client.sendMessage(
            chat,
            {
              message
            }
          );

          success += batch.length;
        } catch (retryError) {
          failed += batch.length;

          console.error(
            "[TAGALL RETRY ERROR]",
            retryError
          );
        }
      } else {
        failed += batch.length;

        console.error(
          "[TAGALL ERROR]",
          err
        );
      }
    }

    if (batchIndex < batches.length - 1) {
      await sleep(1200);
    }
  }

  await reply(
    event,
    [
      "Tagall selesai.",
      "",
      `Total member : ${fmt(filtered.length)}`,
      `Berhasil     : ${fmt(success)}`,
      `Gagal        : ${fmt(failed)}`,
      `Batch        : ${fmt(batches.length)}`
    ].join("\n")
  );
}

async function resolveBlacklistId(
  event,
  args
) {
  if (args) {
    const firstArg = args.split(/\s+/)[0];

    const normalized = normalizeId(firstArg);

    if (normalized) {
      return normalized;
    }
  }

  const replied = await getReplyMessage(event);

  if (!replied) {
    return null;
  }

  if (
    replied.senderId !== undefined &&
    replied.senderId !== null
  ) {
    return String(replied.senderId);
  }

  try {
    const sender = await replied.getSender();

    if (
      sender &&
      sender.id !== undefined
    ) {
      return String(sender.id);
    }
  } catch (err) {
    console.error(
      "[GET REPLY SENDER ERROR]",
      err
    );
  }

  return null;
}

async function handleAddBlacklist(
  event,
  args
) {
  const id = await resolveBlacklistId(
    event,
    args
  );

  if (!id) {
    await reply(
      event,
      `Gunakan ${config.PREFIX}addbl <id> atau reply pesan user.`
    );

    return;
  }

  if (isBlacklisted(id)) {
    await reply(
      event,
      `ID ${id} sudah ada di blacklist.`
    );

    return;
  }

  const result = addBlacklist(id);

  if (!result) {
    await reply(
      event,
      "Gagal menambahkan ID ke blacklist."
    );

    return;
  }

  await reply(
    event,
    `Berhasil menambahkan ${id} ke blacklist.`
  );
}

async function handleRemoveBlacklist(
  event,
  args
) {
  const id = await resolveBlacklistId(
    event,
    args
  );

  if (!id) {
    await reply(
      event,
      `Gunakan ${config.PREFIX}delbl <id> atau reply pesan user.`
    );

    return;
  }

  if (!isBlacklisted(id)) {
    await reply(
      event,
      `ID ${id} tidak ditemukan di blacklist.`
    );

    return;
  }

  const result = removeBlacklist(id);

  if (!result) {
    await reply(
      event,
      "Gagal menghapus ID dari blacklist."
    );

    return;
  }

  await reply(
    event,
    `Berhasil menghapus ${id} dari blacklist.`
  );
}

async function handleListBlacklist(
  event
) {
  const db = loadDB();

  if (!db.blacklist.length) {
    await reply(
      event,
      "Blacklist masih kosong."
    );

    return;
  }

  const lines = [
    "╭━━━「 BLACKLIST 」━━━╮"
  ];

  db.blacklist.forEach((id, index) => {
    lines.push(
      `┃ ${index + 1}. ${id}`
    );
  });

  lines.push(
    "╰━━━━━━━━━━━━━━━━━━━╯",
    "",
    `Total: ${fmt(db.blacklist.length)}`
  );

  await reply(
    event,
    lines.join("\n")
  );
}

async function handleMessage(
  event,
  client
) {
  if (!event || !event.message) {
    return;
  }

  const messageText = event.message.message;

  if (
    !messageText ||
    typeof messageText !== "string"
  ) {
    return;
  }

  if (
    !messageText.startsWith(config.PREFIX)
  ) {
    return;
  }

  const parsed = parseCommand(
    messageText
  );

  if (!parsed) {
    return;
  }

  const senderId = getSenderId(event);
  const owner = isOwner(senderId);

  const command = parsed.command;
  const args = parsed.args;

  if (command === "menu" || command === "help") {
    await handleMenu(event, owner);
    return;
  }

  if (command === "tagall") {
    await handleTagAll(
      event,
      client,
      args
    );

    return;
  }

  const ownerCommands = new Set([
    "broadcast",
    "bc",
    "bcgroup",
    "bcg",
    "bcprivate",
    "bcp",
    "addbl",
    "delbl",
    "listbl"
  ]);

  if (
    ownerCommands.has(command) &&
    !owner
  ) {
    return;
  }

  if (
    command === "broadcast" ||
    command === "bc"
  ) {
    let mediaInfo = null;

    const replied = await getReplyMessage(
      event
    );

    if (replied) {
      mediaInfo = detectMedia(replied);
    }

    if (!args && !mediaInfo) {
      await reply(
        event,
        `Gunakan ${config.PREFIX}broadcast <teks> atau reply foto/video dengan command broadcast.`
      );

      return;
    }

    await executeBroadcast(
      event,
      client,
      "broadcast",
      {
        text: args,
        mediaInfo
      }
    );

    return;
  }

  if (
    command === "bcgroup" ||
    command === "bcg"
  ) {
    let mediaInfo = null;

    const replied = await getReplyMessage(
      event
    );

    if (replied) {
      mediaInfo = detectMedia(replied);
    }

    if (!args && !mediaInfo) {
      await reply(
        event,
        `Gunakan ${config.PREFIX}bcgroup <teks> atau reply foto/video.`
      );

      return;
    }

    await executeBroadcast(
      event,
      client,
      "group",
      {
        text: args,
        mediaInfo
      }
    );

    return;
  }

  if (
    command === "bcprivate" ||
    command === "bcp"
  ) {
    let mediaInfo = null;

    const replied = await getReplyMessage(
      event
    );

    if (replied) {
      mediaInfo = detectMedia(replied);
    }

    if (!args && !mediaInfo) {
      await reply(
        event,
        `Gunakan ${config.PREFIX}bcprivate <teks> atau reply foto/video.`
      );

      return;
    }

    await executeBroadcast(
      event,
      client,
      "private",
      {
        text: args,
        mediaInfo
      }
    );

    return;
  }

  if (command === "addbl") {
    await handleAddBlacklist(
      event,
      args
    );

    return;
  }

  if (command === "delbl") {
    await handleRemoveBlacklist(
      event,
      args
    );

    return;
  }

  if (command === "listbl") {
    await handleListBlacklist(event);
    return;
  }
}

module.exports = {
  handleMessage,
  reply,
  getReplyMessage,
  sleep,
  isOwner,
  fmt,
  mention,
  chunk,
  detectMedia,
  loadDB,
  saveDB,
  isBlacklisted,
  addBlacklist,
  removeBlacklist
};