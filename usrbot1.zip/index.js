const fs = require("fs");
const path = require("path");

const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const input = require("input");

const config = require("./config");
const { handleMessage } = require("./bot");

const SESSION_DIR = path.join(__dirname, "session");
const SESSION_FILE = path.join(SESSION_DIR, "userbot.session");

let client = null;

function ensureSessionDirectory() {
  if (!fs.existsSync(SESSION_DIR)) {
    fs.mkdirSync(SESSION_DIR, { recursive: true });
  }

  if (!fs.existsSync(SESSION_FILE)) {
    fs.writeFileSync(SESSION_FILE, "", "utf8");
  }
}

function loadSession() {
  ensureSessionDirectory();

  return fs.readFileSync(SESSION_FILE, "utf8").trim();
}

function saveSession(session) {
  ensureSessionDirectory();
  fs.writeFileSync(SESSION_FILE, session, "utf8");
}

async function main() {
  if (!Number.isInteger(config.API_ID) || !config.API_ID) {
    throw new Error("API_ID tidak valid. Silakan isi .env.");
  }

  if (!config.API_HASH) {
    throw new Error("API_HASH belum diisi. Silakan isi .env.");
  }

  if (!Number.isInteger(config.OWNER_ID) || !config.OWNER_ID) {
    throw new Error("OWNER_ID tidak valid. Silakan isi .env.");
  }

  const sessionString = loadSession();
  const stringSession = new StringSession(sessionString);

  client = new TelegramClient(
    stringSession,
    config.API_ID,
    config.API_HASH,
    {
      connectionRetries: 5
    }
  );

  await client.start({
    phoneNumber: async () => {
      return await input.text("Nomor Telegram: ");
    },

    password: async () => {
      return await input.text("Password 2FA: ");
    },

    phoneCode: async () => {
      return await input.text("Kode OTP Telegram: ");
    },

    onError: (err) => {
      console.error("[LOGIN ERROR]", err);
    }
  });

  const savedSession = client.session.save();
  saveSession(savedSession);

  const me = await client.getMe();

  console.log("");
  console.log("========================================");
  console.log(" Telegram Userbot berhasil login");
  console.log("========================================");
  console.log(`Nama : ${me.firstName || ""} ${me.lastName || ""}`.trim());
  console.log(`ID   : ${me.id}`);
  console.log(`User : ${me.username ? "@" + me.username : "-"}`);
  console.log("========================================");
  console.log("");

  client.addEventHandler(
    async (event) => {
      try {
        await handleMessage(event, client);
      } catch (err) {
        console.error("[HANDLER ERROR]", err);
      }
    },
    new NewMessage({
      incoming: false
    })
  );

  console.log("Userbot aktif.");
  console.log(`Prefix: ${config.PREFIX}`);
}

process.on("unhandledRejection", (reason) => {
  console.error("[UNHANDLED REJECTION]", reason);
});

process.on("uncaughtException", (err) => {
  console.error("[UNCAUGHT EXCEPTION]", err);
});

async function shutdown(signal) {
  console.log(`\nMenerima ${signal}. Menutup koneksi...`);

  try {
    if (client) {
      await client.disconnect();
    }
  } catch (err) {
    console.error("[SHUTDOWN ERROR]", err);
  }

  process.exitCode = 0;
}

process.once("SIGINT", () => {
  shutdown("SIGINT");
});

process.once("SIGTERM", () => {
  shutdown("SIGTERM");
});

main().catch((err) => {
  console.error("[STARTUP ERROR]", err);
});